CREATE TABLE [dbo].[vb_tbl_log_dtls] (
    [log_id]        BIGINT         IDENTITY NOT NULL,
    [jobid]         BIGINT         NULL,
    [pipeline_id]   VARCHAR (100)  NULL,
    [start_time]    DATETIME2 (6)  NULL,
    [end_time]      DATETIME2 (6)  NULL,
    [status]        VARCHAR (50)   NULL,
    [error_message] VARCHAR (8000) NULL
);


GO