CREATE TABLE [dbo].[vb_tbl_trigger] (
    [trigger_id]   BIGINT        IDENTITY NOT NULL,
    [trigger_name] VARCHAR (100) NOT NULL,
    [created_user] VARCHAR (50)  NULL,
    [created_date] DATETIME2 (6) NULL,
    [updated_user] VARCHAR (50)  NULL,
    [updated_date] DATETIME2 (6) NULL
);


GO