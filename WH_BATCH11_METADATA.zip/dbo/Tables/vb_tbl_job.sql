CREATE TABLE [dbo].[vb_tbl_job] (
    [jobid]          BIGINT        IDENTITY NOT NULL,
    [trigger_id]     BIGINT        NOT NULL,
    [L2_switch_type] VARCHAR (50)  NULL,
    [L3_switch_type] VARCHAR (50)  NULL,
    [L4_switch_type] VARCHAR (50)  NULL,
    [created_user]   VARCHAR (50)  NULL,
    [created_date]   DATETIME2 (6) NULL,
    [updated_user]   VARCHAR (50)  NULL,
    [updated_date]   DATETIME2 (6) NULL
);


GO