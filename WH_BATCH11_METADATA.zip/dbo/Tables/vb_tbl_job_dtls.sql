CREATE TABLE [dbo].[vb_tbl_job_dtls] (
    [dtls_id]      BIGINT        IDENTITY NOT NULL,
    [jobid]        BIGINT        NOT NULL,
    [dtls_key]     VARCHAR (100) NULL,
    [dtls_value]   VARCHAR (500) NULL,
    [created_user] VARCHAR (50)  NULL,
    [created_date] DATETIME2 (6) NULL,
    [updated_user] VARCHAR (50)  NULL,
    [updated_date] DATETIME2 (6) NULL
);


GO