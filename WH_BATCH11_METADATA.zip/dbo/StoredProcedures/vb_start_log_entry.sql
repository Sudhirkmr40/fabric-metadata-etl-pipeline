-- 3. Stored Procedures recreate karein
CREATE   PROCEDURE dbo.vb_start_log_entry
    @jobid BIGINT,
    @pipeline_id VARCHAR(100)
AS
BEGIN
    INSERT INTO dbo.vb_tbl_log_dtls (jobid, pipeline_id, start_time, status)
    VALUES (@jobid, @pipeline_id, CURRENT_TIMESTAMP, 'Running');
END;

GO