CREATE   PROCEDURE dbo.vb_end_log_entry
    @jobid BIGINT,
    @pipeline_id VARCHAR(100),
    @error VARCHAR(8000) = NULL
AS
BEGIN
    UPDATE dbo.vb_tbl_log_dtls
    SET end_time = CURRENT_TIMESTAMP,
        status = CASE WHEN @error IS NULL OR @error = '' THEN 'Completed' ELSE 'Failed' END,
        error_message = @error
    WHERE jobid = @jobid AND pipeline_id = @pipeline_id;
END;

GO