CREATE   PROCEDURE dbo.vb_get_job_dtls
    @TriggerName VARCHAR(100)
AS
BEGIN
    SELECT 
        j.jobid,
        MAX(CASE WHEN d.dtls_key = 'sourcedata' THEN d.dtls_value END) AS sourcedata,
        MAX(CASE WHEN d.dtls_key = 'sourcefile' THEN d.dtls_value END) AS sourcefile,
        MAX(CASE WHEN d.dtls_key = 'delimiter' THEN d.dtls_value END) AS delimiter,
        MAX(CASE WHEN d.dtls_key = 'sheetname' THEN d.dtls_value END) AS sheetname
    FROM dbo.vb_tbl_trigger t
    JOIN dbo.vb_tbl_job j ON t.trigger_id = j.trigger_id
    LEFT JOIN dbo.vb_tbl_job_dtls d ON j.jobid = d.jobid
    WHERE t.trigger_name = @TriggerName
    GROUP BY j.jobid;
END;

GO